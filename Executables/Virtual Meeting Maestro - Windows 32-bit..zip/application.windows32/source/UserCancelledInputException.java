/**
  * An exception thrown when user cancels a process they are pursuing.
  */
public class UserCancelledInputException extends Exception {
}

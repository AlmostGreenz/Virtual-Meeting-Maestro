/**
  * An exception thrown when the storage file format is invalid (likely due to tampering).
  */
public class InvalidFileFormatException extends RuntimeException {
}
